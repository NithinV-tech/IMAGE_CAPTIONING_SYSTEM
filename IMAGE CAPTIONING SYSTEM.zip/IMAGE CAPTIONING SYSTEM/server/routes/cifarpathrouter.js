const express = require('express');
const router = express.Router();
const { isAdmin } = require('../middleware/authMiddleware');

const {storecifarvar} = require('./storecifarimages')

router.post('/storecifar/postapi',isAdmin,storecifarvar);

const {getImagesByCaption} = require('./queryimages')

router.post('/querycifar/postapi',getImagesByCaption);


module.exports=router;