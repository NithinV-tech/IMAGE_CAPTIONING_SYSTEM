const cifarimage = require('../models/image_details');
const multer = require('multer');
const Jimp = require('jimp');

const storecifarvar = async (req, res) => {
    try {
        const storage = multer.diskStorage({
            destination: './cifar_image_uploads',
            filename: function (req, file, cb) {
                cb(null, file.originalname);
            },
        });

        const upload = multer({
            storage: storage,
            limits: { fileSize: 10000000000 }, // 10MB limit
        }).single('file');

        upload(req, res, async (err) => {
            if (err) {
                console.error('Error uploading image:', err);
                return res.status(500).json({ error: 'Error uploading image' });
            }

            if (!req.file) {
                console.log("file not found");
                return res.status(400).json({ error: 'No file uploaded' });
            }

            const { caption, user_uploaded } = req.body;

            console.log('Image uploaded details:', {
                imageUrl: req.file.filename,
                caption: caption,
                user_uploaded: user_uploaded
            });

            // Resize the image using jimp
            const imagePath = './cifar_image_uploads/' + req.file.filename;
            const image = await Jimp.read(imagePath);
            await image.resize(600, 400).quality(90).writeAsync(imagePath);

            const newImage = new cifarimage({
                imageUrl: req.file.filename,
                caption: caption,
                user_uploaded: user_uploaded,
            });

            const savedimage = await newImage.save();

            res.json({
                message: 'Image uploaded Successfully',
                imageUrl: newImage.imageUrl,
                caption: newImage.caption,
                user_uploaded: newImage.user_uploaded
            });
        });

    } catch (error) {
        console.error('Error handling image upload:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

module.exports = { storecifarvar };
