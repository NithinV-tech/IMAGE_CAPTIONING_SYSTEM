const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const Admin = require('../models/userdb');  

const handleLogin = async (req, res) => {
    try {
        const { username, password } = req.body;

        const user = await Admin.findOne({ username });
        if (!user) {
            console.log('User not found:', username);
            return res.status(404).json({ message: 'Username does not exist' });
        }

        const passwordIsValid = bcrypt.compareSync(password, user.password);
        if (!passwordIsValid) {
            console.log('Invalid password for:', username);
            return res.status(401).json({ message: 'Password is incorrect' });
        }

        console.log('Password is correct. Generating JWT token.');
        const secretKey = process.env.JWT_SECRET;
        const token = jwt.sign('iamtheadmin',secretKey);
           

        console.log('JWT token generated:', token);

        res.json({
            Status: "Success",
            token,
            role: user.role || 'user'  
        });
    } catch (error) {
        console.error('Error during login:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

module.exports = { handleLogin };
