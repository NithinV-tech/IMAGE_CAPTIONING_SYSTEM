const bcrypt = require('bcrypt');
const Admin = require('../models/userdb');  // Assuming this imports correctly your model

const handleRegister = async (req, res) => {
    try {
        const { username, password } = req.body;

        // Check if the user already exists in the database
        const existingUser = await Admin.findOne({ username });
        if (existingUser) {
            console.log('Registration failed: username already exists.');
            return res.status(409).json({ error: 'Username already exists' });
        }

        // Hash the password asynchronously
        const hashedPassword = await bcrypt.hash(password, 10);
        console.log('Password hashed:', hashedPassword);

        // Create new user in the database
        const newUser = new Admin({
            username,
            password: hashedPassword // Store the hashed password
        });
        await newUser.save();

        console.log('New user registered:', newUser);
        res.status(201).json({ message: 'User registered successfully' });
    } catch (error) {
        console.error('Error during registration:', error);
        if (error.name === 'MongoError' && error.code === 11000) {
            return res.status(409).json({ error: 'Database error: Duplicate username' });
        }
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

module.exports = { handleRegister };
