/*
const cifarimage = require('../models/image_details');
const express = require('express');
const app = express();
app.use(express.json());

const getImagesByCaption = async (req, res) => {
    try {
        const { caption } = req.body; // Change req.params to req.body
        console.log('Requested caption:', caption);

        // Find all images with the given caption
        const images = await cifarimage.find({ caption: caption });
        console.log('Found images:', images);

        if (images.length === 0) {
            console.log('No images found with the specified caption');
            return res.status(404).json({ error: 'No images found with the specified caption' });
        }

        // Extract image URLs from the database records
        const imageUrls = images.map(image => image.imageUrl);
        console.log('Image URLs:', imageUrls);

        res.json({ images: imageUrls }); // Change imageUrls to images
    } catch (error) {
        console.error('Error retrieving images by caption:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

module.exports = { getImagesByCaption };
*/
/*
const cifarimage = require('../models/image_details');
const fs = require('fs/promises');
const path = require('path');

const getImagesByCaption = async (req, res) => {
    try {
        const { caption } = req.body;
        console.log('Requested caption:', caption);

        // Find all images with the given caption
        const images = await cifarimage.find({ caption: caption });
        console.log('Found images:', images);

        if (images.length === 0) {
            console.log('No images found with the specified caption');
            return res.status(404).json({ error: 'No images found with the specified caption' });
        }

        // Extract image URLs and filenames from the database records
        const imageDetails = images.map(image => ({
            imageUrl: image.imageUrl,
            filename: path.basename(image.imageUrl) // Extract filename from the URL
        }));
        console.log('Image details:', imageDetails);

        // Send image details to the frontend
        res.json({ images: imageDetails });
    } catch (error) {
        console.error('Error retrieving images by caption:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

module.exports = { getImagesByCaption };
*/

const cifarimage = require('../models/image_details');
const fs = require('fs/promises');
const path = require('path');

const getImagesByCaption = async (req, res) => {
    try {
        const { caption } = req.body;
        console.log('Requested caption:', caption);

        // Find all images with the given caption
        const images = await cifarimage.find({ caption: caption });
        console.log('Found images:', images);

        if (images.length === 0) {
            console.log('No images found with the specified caption');
            return res.status(404).json({ error: 'No images found with the specified caption' });
        }

        // Extract image URLs and filenames from the database records
        const imageDetails = [];

        // Read each image file and convert to base64
        for (const image of images) {
            const filename = path.basename(image.imageUrl);
            const filePath = path.join(__dirname, '..', 'cifar_image_uploads', filename);
            const imageData = await fs.readFile(filePath, { encoding: 'base64' });
            imageDetails.push({ imageUrl: image.imageUrl, filename: filename, imageData: imageData });
        }

        console.log('Image details:', imageDetails);

        // Send image details to the frontend
        res.json({ images: imageDetails });
    } catch (error) {
        console.error('Error retrieving images by caption:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

module.exports = { getImagesByCaption };
