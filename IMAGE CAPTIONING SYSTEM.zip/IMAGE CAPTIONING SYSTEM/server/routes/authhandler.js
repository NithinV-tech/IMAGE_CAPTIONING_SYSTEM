const {handleLogin} = require('./login')
const {handleRegister} = require('./register')
const express = require('express');
const router = express.Router();

router.post('/login/postapi',handleLogin);
router.post('/register/postapi',handleRegister)

module.exports=router;