const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const routes = require('./routes/cifarpathrouter');
const loginRoutes = require('./routes/authhandler');
const app = express();

require('dotenv').config();

app.use(cors({
    origin: 'http://localhost:5173',  
    credentials: true  
}));

app.use(express.json());

const PORT = process.env.PORT || 3000;
console.log("Connecting to", process.env.MONGODB_URI);

mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

mongoose.connection.on('connected', () => {
  console.log('Connected to MongoDB');
});

app.use('/api', routes);
app.use('/authapi', loginRoutes);

app.listen(PORT, () => {
    console.log("Server running fine on port", PORT);
});
