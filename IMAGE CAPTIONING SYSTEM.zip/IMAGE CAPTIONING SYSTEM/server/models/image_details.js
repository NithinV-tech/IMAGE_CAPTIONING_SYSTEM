const mongoose = require('mongoose');

const image_schema = new mongoose.Schema({
  imageUrl: String,
  caption:String,
  user_uploaded: String,
});


module.exports = mongoose.model('Image', image_schema);