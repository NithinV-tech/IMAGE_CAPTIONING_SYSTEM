import { useState } from 'react'
import './App.css'
import {BrowserRouter,Routes,Route} from 'react-router-dom'
import 'bootstrap/dist/css/bootstrap.min.css'
import Landing from './pages/Landing';

import QueryPage from './pages/QueryPage';
import Login from './pages/Login';
import Signup from  './pages/Signup';

function App() {
  const [count, setCount] = useState(0)


  return (
    <div>
      <BrowserRouter>
      <Routes>
      <Route path ="/login" element={<Login/>} ></Route>
      <Route path ="/register" element={<Signup/>} ></Route>
        <Route path ="/" element={<Landing/>} ></Route>
        <Route path ="/QueryPage" element={<QueryPage/>} ></Route>
      </Routes>

      </BrowserRouter>
      
    </div>
  )
}

export default App
