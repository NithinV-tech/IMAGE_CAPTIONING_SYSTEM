
import React, { useState, useEffect } from 'react';
import './QueryPage.css';
import { CircularProgress, Snackbar, MenuItem, Select, Pagination } from '@mui/material';
import MuiAlert from '@mui/material/Alert';
import { Link as RouterLink } from 'react-router-dom';
import Cookies from 'js-cookie';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSignOutAlt } from '@fortawesome/free-solid-svg-icons';
import { faUpload, faTimes } from '@fortawesome/free-solid-svg-icons';
import { useNavigate } from 'react-router-dom';

const QueryPage = () => {
    const navigate = useNavigate();
    useEffect(() => {
      const token = Cookies.get('token');
  
      if (!token ) {
        navigate('/login');
        return;
      }
    }, []);
    const handleLogout = () => {
        Cookies.remove('token'); 
        navigate('/login');
    };
  



    const [selectedCaption, setSelectedCaption] = useState(' ');
    const [images, setImages] = useState([]);
    const [loading, setLoading] = useState(false);
    const [errorMessage, setErrorMessage] = useState('');
    const [openSnackbar, setOpenSnackbar] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    const [imagesPerPage] = useState(5);
 



    useEffect(() => {
        fetchImages();
    }, [selectedCaption, currentPage]); 

    function getToken() {
        return Cookies.get('token');
    }




    const fetchImages = async () => {
        if (selectedCaption.trim() === '') return;

        setLoading(true);
        try {
            const response = await fetch('http://localhost:3000/api/querycifar/postapi', {
                method: 'POST',
    
                    headers: {
                        'Authorization': 'Bearer ' + getToken(), 
                        'Content-Type': 'application/json'
                    },
                
                body: JSON.stringify({ caption: selectedCaption })
            });

            if (!response.ok) {
                if (response.status === 404) {
                    throw new Error('No images found for the selected caption');
                } else {
                    throw new Error('Network response was not ok');
                }
            }

            const data = await response.json();
            setImages(data.images);
            setErrorMessage('');
        } catch (error) {
            console.error('Error fetching images:', error);
            setErrorMessage(error.message);
            setOpenSnackbar(true);
        } finally {
            setLoading(false);
        }
    };

    const handleDropdownChange = (event) => {
        setSelectedCaption(event.target.value);
        setCurrentPage(1); 
        setImages([]);
    };

    const handlePageChange = (event, newPage) => {
        setCurrentPage(newPage);
    };

    const handleCloseSnackbar = () => {
        setOpenSnackbar(false);
    };


    const renderSnackbarContent = () => {
        if (errorMessage) {
            return <MuiAlert elevation={6} variant="filled" onClose={handleCloseSnackbar} severity="error">{errorMessage}</MuiAlert>;
        }
        return null;
    };

    const renderImagesForCurrentPage = () => {
        const startIndex = (currentPage - 1) * imagesPerPage;
        const endIndex = Math.min(startIndex + imagesPerPage, images.length);
        const imagesToDisplay = images.slice(startIndex, endIndex);
    
        return (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '20px' }}>
                {imagesToDisplay.map((image, index) => (
                    <div key={index} className="image-container">
                        <img
                            src={`data:image/jpeg;base64,${image.imageData}`}
                            alt={`Caption ${selectedCaption}`}
                            style={{ width: '200px', height: 'auto' }} 
                        />
                        <div style={{ marginTop: '10px', textAlign: 'center' }}>
                            {image.filename}
                        </div>
                    </div>
                ))}
            </div>
        );
    };
    

    return (
        <div>
            <button className="logout-button" onClick={handleLogout} style={{ position: 'absolute', top: '10px', right: '10px' }}>
            <FontAwesomeIcon icon={faSignOutAlt} /> Logout
        </button>
            <h1>Select which of the following captions you need to retrieve?</h1>
            <Select
                value={selectedCaption}
                onChange={handleDropdownChange}
                variant="outlined"
                fullWidth
                sx={{ width: '200px', marginBottom: '20px' }} 
            >
                <MenuItem value=" ">Select...</MenuItem>
                <MenuItem value="airplane">Airplane</MenuItem>
                <MenuItem value="automobile">Automobile</MenuItem>
                <MenuItem value="bird">Bird</MenuItem>
                <MenuItem value="cat">Cat</MenuItem>
                <MenuItem value="deer">Deer</MenuItem>
                <MenuItem value="dog">Dog</MenuItem>
                <MenuItem value="frog">Frog</MenuItem>
                <MenuItem value="horse">Horse</MenuItem>
                <MenuItem value="ship">Ship</MenuItem>
                <MenuItem value="truck">Truck</MenuItem>
            </Select>
            <div style={{ marginBottom: '20px' }}></div>
            <button className="button" onClick={fetchImages}>Fetch Images</button>

            <div style={{ marginTop: '20px', textAlign: 'center' }}>
                <RouterLink to="/" style={{ textDecoration: 'none' }}>
                    <button className="button" > Go Home</button>
                </RouterLink>
            </div>

            {loading && <CircularProgress />}
            <p style={{ marginTop: '50px' }}></p>
           

            {renderImagesForCurrentPage()}

            <div style={{ display: 'flex', justifyContent: 'center', marginTop: '20px' }}>
                <Pagination
                    count={Math.ceil(images.length / imagesPerPage)}
                    page={currentPage}
                    onChange={handlePageChange}
                    shape="rounded"
                />
            </div>

            <Snackbar
                anchorOrigin={{
                    vertical: 'top',
                    horizontal: 'center',
                }}
                style={{ marginTop: '300px' }}
                open={openSnackbar}
                autoHideDuration={6000}
                onClose={handleCloseSnackbar}
            >
                {renderSnackbarContent()}
            </Snackbar>
        </div>
    );
};

export default QueryPage;
