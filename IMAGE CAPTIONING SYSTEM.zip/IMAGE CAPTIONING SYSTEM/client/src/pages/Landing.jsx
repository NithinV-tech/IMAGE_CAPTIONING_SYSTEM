import React, { useState, useRef } from 'react';
import './landing.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSignOutAlt } from '@fortawesome/free-solid-svg-icons';
import { faUpload, faTimes } from '@fortawesome/free-solid-svg-icons';
import { Link, Snackbar, Alert } from '@mui/material';
import { Link as RouterLink } from 'react-router-dom';
import {  useEffect } from 'react';
import Cookies from 'js-cookie';
import { useNavigate } from 'react-router-dom';

const Landing = () => {
   
    const navigate = useNavigate();
    useEffect(() => {
      const token = Cookies.get('token');
  
      if (!token ) {
        navigate('/login');
        return;
      }
    }, []);


    const handleLogout = () => {
        Cookies.remove('token'); 
        navigate('/login');
    };


    const fileInputRef = useRef(null);
    const [images, setImages] = useState([]);
    const [selectedOptions, setSelectedOptions] = useState([]);
    const [showDropdowns, setShowDropdowns] = useState([]);
    const [imageUrls, setImageUrls] = useState([]);
    const [openSnackbar, setOpenSnackbar] = useState(false);
    const [alertMessage, setAlertMessage] = useState('');
    const [alertSeverity, setAlertSeverity] = useState('success');
    const [dragging, setDragging] = useState(false);

    const handleImageUpload = (event) => {
        const fileList = event.target.files;
        const currentTimeStamp = Date.now(); 
        const updatedImageUrls = [];
        const updatedImages = Array.from(fileList).map((file,index) => {
            const timestampedFilename = `${currentTimeStamp}_${file.name}`; 
            updatedImageUrls.push(URL.createObjectURL(file));
            return new File([file], timestampedFilename, { type: file.type }); 
        });
        setImages(updatedImages);
        setShowDropdowns(Array.from({ length: fileList.length }, () => true));
        setImageUrls(updatedImageUrls);
    };
    

    const handleDragOver = (event) => {
        event.preventDefault();
        setDragging(true);
    };

    const handleDragEnter = (event) => {
        event.preventDefault();
        setDragging(true);
    };

    const handleDragLeave = (event) => {
        event.preventDefault();
        setDragging(false);
    };

    const handleDrop = (event) => {
        event.preventDefault();
        setDragging(false);
        const fileList = event.dataTransfer.files;
        const imageArray = Array.from(fileList).map((file) => URL.createObjectURL(file));
        setImages(fileList);
        setShowDropdowns(Array.from({ length: fileList.length }, () => true));
        setImageUrls(imageArray);
    };

    const handleChooseImageButtonClick = () => {
        fileInputRef.current.click();
    };

    const handleCloseSnackbar = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }
        setOpenSnackbar(false);
    };

    function getToken() {
        return Cookies.get('token');
    }

    const handleDropdownChange = (index, event) => {
        const updatedOptions = [...selectedOptions];
        updatedOptions[index] = event.target.value;
        setSelectedOptions(updatedOptions);
    };

    const handleCancelImage = (index) => {
        const updatedImages = [...images];
        const updatedSelectedOptions = [...selectedOptions];
        const updatedShowDropdowns = [...showDropdowns];
        const updatedImageUrls = [...imageUrls];

        updatedImages.splice(index, 1);
        updatedSelectedOptions.splice(index, 1);
        updatedShowDropdowns.splice(index, 1);
        updatedImageUrls.splice(index, 1);

        setImages(updatedImages);
        setSelectedOptions(updatedSelectedOptions);
        setShowDropdowns(updatedShowDropdowns);
        setImageUrls(updatedImageUrls);
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        let allUploadsSuccessful = true;

        for (let i = 0; i < images.length; i++) {
            const formData = new FormData();
            formData.append('file', images[i]);
            formData.append('caption', selectedOptions[i]);
            formData.append('user_uploaded', true);

            try {
                const response = await fetch('http://localhost:3000/api/storecifar/postapi', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'Authorization': 'Bearer ' + getToken(), 
                    }, 
                    
                });

                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }

                const data = await response.json();
                console.log('Response from backend:', data);
            } catch (error) {
                console.error('Error:', error);
                allUploadsSuccessful = false;
                setAlertMessage('Failed to upload images');
                setAlertSeverity('error');
                setOpenSnackbar(true);
                break;
            }
        }

        if (allUploadsSuccessful) {
            setAlertMessage('Images successfully uploaded');
            setAlertSeverity('success');
            setOpenSnackbar(true);
            setImageUrls([]);
            setImages([]);
            setSelectedOptions([]);
            setShowDropdowns([]);
        }
    };

    return (
        <div className={`container ${dragging ? 'dragging' : ''}`} onDragOver={handleDragOver} onDragEnter={handleDragEnter} onDragLeave={handleDragLeave} onDrop={handleDrop}>
            <h1>Upload Image and Annotate</h1>
            <button className="logout-button" onClick={handleLogout} style={{ position: 'absolute', top: '10px', right: '10px' }}>
            <FontAwesomeIcon icon={faSignOutAlt} /> Logout
        </button>
            <div className="upload-container">
                <div className="upload-space" />
                <button className="upload-button" onClick={handleChooseImageButtonClick}>
                    <FontAwesomeIcon icon={faUpload} className="upload-icon" />
                    Choose Image
                </button>
                <input
                    type="file"
                    ref={fileInputRef}
                    accept="image/*"
                    onChange={handleImageUpload}
                    style={{ display: 'none' }}
                    multiple 
                />
                 <p style={{ marginTop: '10px' }}></p>
                <p>Drag & drop images here or click to choose</p>
            </div>
            {imageUrls.map((imageUrl, index) => (
                <div key={index}>
                    <div className="image-preview">
                        <img src={imageUrl} alt="Uploaded" />
                        <p>Kindly annotate the image with the ones in the dropdown:</p>
                        {showDropdowns[index] && (
                            <div className="dropdown-container">
                                <select
                                    value={selectedOptions[index] || ''}
                                    onChange={(event) => handleDropdownChange(index, event)}
                                    style={{ width: '100%', padding: '10px', fontSize: '16px', borderRadius: '5px', border: '1px solid #ccc', backgroundColor: '#fff' }}
                                >
                                    <option value="">Select...</option>
                                    <option value="airplane">Airplane</option>
                                    <option value="automobile">Automobile</option>
                                    <option value="bird">Bird</option>
                                    <option value="cat">Cat</option>
                                    <option value="deer">Deer</option>
                                    <option value="dog">Dog</option>
                                    <option value="frog">Frog</option>
                                    <option value="horse">Horse</option>
                                    <option value="ship">Ship</option>
                                    <option value="truck">Truck</option>
                                </select>
                                <button className="cancelbutton" onClick={() => handleCancelImage(index)}>
                                    
                                    Cancel
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            ))}
            {images.length > 0 && (
                <div className="button-container">
                    <button type="submit" className="button" onClick={handleSubmit}>Submit</button>
                </div>
            )}
            <div className="button-container">
                <Link component={RouterLink} to="/QueryPage">
                    <button className='button'>Search</button>
                </Link>
            </div>
            <Snackbar
                open={openSnackbar}
                autoHideDuration={6000}
                onClose={handleCloseSnackbar}
                anchorOrigin={{ vertical: 'center', horizontal: 'center' }} 
                style={{ marginBottom: '300px' }}
            >
                <Alert onClose={handleCloseSnackbar} severity={alertSeverity} sx={{ width: '100%' }}>
                    {alertMessage}
                </Alert>
            </Snackbar>
        </div>
    );
};

export default Landing;
