import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from 'axios';
import Cookies from 'js-cookie';

import './Login.css';

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:3000/authapi/login/postapi', { username, password });

      if (response.data.Status === "Success") {
        // Redirect to home on successful login
        Cookies.set('token',response.data.token);
        navigate('/');
      }
    } catch (error) {
      if (error.response) {
        const status = error.response.status;
        if (status === 401) {
          setErrorMessage('Username or password is incorrect!');
        } else if (status === 404) {
          setErrorMessage('No such user found');
        } else {
          setErrorMessage('An error occurred. Please try again later.');
        }
      } else {
        console.error(error);
        setErrorMessage('An error occurred. Please check your network connection.');
      }
    }
  };

  return (
    <div className="login-container">
      <div className="login-box">
        <h2 className="login-title">Login</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="username" className="login-label">
              Username
            </label>
            <input
              type="text"
              placeholder="Enter Username"
              autoComplete="off"
              name="username"
              className="form-control login-input"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="password" className="login-label">
              Password
            </label>
            <input
              type="password"
              placeholder="Enter Password"
              name="password"
              className="form-control login-input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="btn btn-primary login-button">
            Login
          </button>
          {errorMessage && (
            <div className="alert alert-danger mt-3" role="alert">
              {errorMessage}
            </div>
          )}
        </form>
        <p className="login-text">Don't have an account?</p>
        <Link to="/register" className="btn btn-secondary login-signup-button">
          Sign Up
        </Link>
      </div>
    </div>
  );
}

export default Login;

